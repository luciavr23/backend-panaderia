package com.example.mapper;

import org.mapstruct.Mapper;

import com.example.dto.AllergenDTO;
import com.example.entity.Allergen;

@Mapper(componentModel = "spring")
public interface AllergenMapper {
	AllergenDTO toDTO(Allergen allergen);

	Allergen toEntity(AllergenDTO allergenDTO);
}
