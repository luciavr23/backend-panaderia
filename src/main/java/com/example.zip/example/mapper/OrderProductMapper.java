package com.example.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.example.dto.OrderProductDTO;
import com.example.entity.OrderProduct;

@Mapper(componentModel = "spring")
public interface OrderProductMapper {

	@Mapping(source = "product.name", target = "productName")
	@Mapping(source = "unitPrice", target = "price")
	OrderProductDTO toDto(OrderProduct entity);

	@Mapping(source = "productName", target = "product.name")
	@Mapping(source = "price", target = "unitPrice")
	OrderProduct toEntity(OrderProductDTO dto);
}
