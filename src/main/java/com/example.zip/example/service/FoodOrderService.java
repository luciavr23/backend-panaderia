package com.example.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dto.FoodOrderDTO;
import com.example.dto.ReviewDTO;
import com.example.entity.BakeryInfo;
import com.example.entity.FoodOrder;
import com.example.entity.UserAccount;
import com.example.mapper.FoodOrderMapper;
import com.example.mapper.ReviewMapper;
import com.example.repository.BakeryInfoRepository;
import com.example.repository.FoodOrderRepository;
import com.example.repository.ReviewRepository;
import com.example.repository.UserAccountRepository;

import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FoodOrderService {
	private final FoodOrderRepository foodOrderRepository;
	private final UserAccountRepository userAccountRepository;
	private final BakeryInfoRepository bakeryInfoRepository;
	@Autowired
	private EmailService emailService;
	private final ReviewRepository reviewRepository;
	private final ReviewMapper reviewMapper;
	private final FoodOrderMapper foodOrderMapper;

	public List<FoodOrderDTO> getOrdersByUsername(String email) {
		UserAccount user = userAccountRepository.findByEmail(email)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
		return getOrdersByUserId(user.getId());
	}

	public List<FoodOrderDTO> getOrdersByUserId(Long userId) {
		List<FoodOrder> orders = foodOrderRepository.findByUserId(userId);
		return orders.stream().map(this::toDtoWithReview).collect(Collectors.toList());
	}

	private FoodOrderDTO toDtoWithReview(FoodOrder order) {
		FoodOrderDTO dto = foodOrderMapper.toDto(order);
		ReviewDTO reviewDTO = reviewRepository.findByOrderId(order.getId()).map(reviewMapper::toDTO).orElse(null);
		dto.setReview(reviewDTO);
		return dto;
	}

	public FoodOrder crearPedido(FoodOrder pedido) {
		// Paso 1: guardar sin número para que se genere el ID
		pedido.setOrderNumber(null);
		pedido.setCreatedAt(LocalDateTime.now()); // si no lo estás asignando antes
		FoodOrder saved = foodOrderRepository.save(pedido);

		// Paso 2: generar número de pedido basado en el ID
		String numeroPedido = String.format("PED-%04d", saved.getId());
		saved.setOrderNumber(numeroPedido);

		// Paso 3: actualizar con el número de pedido
		return foodOrderRepository.save(saved);
	}

	public FoodOrderDTO createOrderWithUser(FoodOrder order, String userEmail) {
		UserAccount user = userAccountRepository.findByEmail(userEmail)
				.orElseThrow(() -> new RuntimeException("User not found"));

		order.setUser(user);
		order.setCreatedAt(LocalDateTime.now());
		order.setOrderNumber(null); // Ensure no number yet

		// Step 1: Save to generate ID
		FoodOrder saved = foodOrderRepository.save(order);

		// Step 2: Generate order number using ID
		saved.setOrderNumber(String.format("ORD-%04d", saved.getId()));

		// Step 3: Save again with order number
		saved = foodOrderRepository.save(saved);

		// Step 4: Convert to DTO
		return foodOrderMapper.toDto(saved);
	}

	// Llama esto cuando el cliente paga
	public void notificarPedidoRegistrado(FoodOrder pedido) {
		UserAccount cliente = pedido.getUser();
		List<String> productos = pedido.getItems().stream()
				.map(item -> item.getProduct().getName() + " x" + item.getQuantity()).collect(Collectors.toList());
		String resumen = emailService.buildResumenPedidoHtml(pedido.getId().toString(), productos,
				pedido.getTotalPrice().doubleValue(), null);
		String mensaje = "Se ha registrado tu pedido y pasa a estar en preparación. ¡Gracias por confiar en Panadería Ana!";
		String html = emailService.buildOrderHtml(cliente.getName(), mensaje, resumen, null, null);
		try {
			emailService.sendOrderEmail(cliente.getEmail(), "¡Tu pedido ha sido registrado!", html);
		} catch (MessagingException e) {
			// Manejar error de envío
		}
	}

	// Llama esto cuando el admin marca como completado
	public void notificarPedidoCompletado(FoodOrder pedido, String fechaRecogida) {
		UserAccount cliente = pedido.getUser();
		List<String> productos = pedido.getItems().stream()
				.map(item -> item.getProduct().getName() + " x" + item.getQuantity()).collect(Collectors.toList());
		String resumen = emailService.buildResumenPedidoHtml(pedido.getId().toString(), productos,
				pedido.getTotalPrice().doubleValue(), fechaRecogida);
		BakeryInfo info = bakeryInfoRepository.findAll().stream().findFirst().orElse(null);
		String direccion = info != null ? info.getStreet() + ", " + info.getCity() : "";
		String telefono = info != null ? info.getPhone() : "";
		String mensaje = "Tu pedido ya está listo para recoger en tienda.";
		String html = emailService.buildOrderHtml(cliente.getName(), mensaje, resumen, direccion, telefono);
		try {
			emailService.sendOrderEmail(cliente.getEmail(), "¡Tu pedido está listo para recoger!", html);
		} catch (MessagingException e) {
			// Manejar error de envío
		}
	}

	// Llama esto cuando el pedido es cancelado
	public void notificarPedidoCancelado(FoodOrder pedido) {
		UserAccount cliente = pedido.getUser();
		List<String> productos = pedido.getItems().stream()
				.map(item -> item.getProduct().getName() + " x" + item.getQuantity()).collect(Collectors.toList());
		String resumen = emailService.buildResumenPedidoHtml(pedido.getId().toString(), productos,
				pedido.getTotalPrice().doubleValue(), null);
		String mensaje = "Lamentamos las molestias, tu pedido ha sido cancelado.";
		String html = emailService.buildOrderHtml(cliente.getName(), mensaje, resumen, null, null);
		try {
			emailService.sendOrderEmail(cliente.getEmail(), "Pedido cancelado", html);
		} catch (MessagingException e) {
			// Manejar error de envío
		}
	}

}
