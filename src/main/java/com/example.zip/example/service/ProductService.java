package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.dto.AllergenDTO;
import com.example.dto.ProductDTO;
import com.example.dto.ProductImageDTO;
import com.example.entity.Allergen;
import com.example.entity.Product;
import com.example.entity.ProductAllergen;
import com.example.entity.ProductCategory;
import com.example.entity.ProductImage;
import com.example.mapper.ProductMapper;
import com.example.repository.AllergenRepository;
import com.example.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {

	private final ProductRepository productRepository;
	private final ProductMapper productMapper;
	@Autowired
	private AllergenRepository allergenRepository;

	public List<ProductDTO> getAllProductsWithoutCategory() {
		return productRepository.findByAvailableTrue().stream().map(productMapper::toDTO).collect(Collectors.toList());
	}

	public Page<ProductDTO> getAllProducts(int page, int size, String sortBy, String direction, String search,
			Long categoryId) {
		Sort.Direction sortDirection = Sort.Direction.fromString(direction.toUpperCase());
		Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

		Page<Product> products;

		if (categoryId != null) {
			if (search != null && !search.isEmpty()) {
				products = productRepository.findByCategoryIdAndNameContainingIgnoreCase(categoryId, search, pageable);
			} else {
				products = productRepository.findByCategoryId(categoryId, pageable);
			}
		} else {
			if (search != null && !search.isEmpty()) {
				products = productRepository.findByNameContainingIgnoreCase(search, pageable);
			} else {
				products = productRepository.findAll(pageable);
			}
		}

		return products.map(productMapper::toDTO);
	}

	public Page<ProductDTO> getAvailableProducts(int page, int size, String sortBy, String direction, String search,
			Long categoryId) {
		Sort.Direction sortDirection = Sort.Direction.fromString(direction.toUpperCase());
		Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));

		Page<Product> products;

		if (categoryId != null) {
			if (search != null && !search.isEmpty()) {
				products = productRepository.findByAvailableTrueAndCategoryIdAndNameContainingIgnoreCase(categoryId,
						search, pageable);
			} else {
				products = productRepository.findByAvailableTrueAndCategoryId(categoryId, pageable);
			}
		} else {
			if (search != null && !search.isEmpty()) {
				products = productRepository.findByAvailableTrueAndNameContainingIgnoreCase(search, pageable);
			} else {
				products = productRepository.findByAvailableTrue(pageable);
			}
		}

		return products.map(productMapper::toDTO);
	}

	public ProductDTO getProductById(Long id) {
		return productRepository.findById(id).map(productMapper::toDTO)
				.orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));
	}

	public List<ProductDTO> getPopularProducts() {
		return productRepository.findByPopularTrue().stream().map(productMapper::toDTO).collect(Collectors.toList());
	}

	public ProductDTO createProduct(ProductDTO dto) {
		Product entity = productMapper.toEntity(dto);

		// Limpia la lista de productAllergens si existe
		if (entity.getAllergens() != null) {
			entity.getAllergens().clear();
		} else {
			entity.setAllergens(new ArrayList<>());
		}

		// Si el DTO trae alérgenos, crea las relaciones correctamente
		if (dto.getAllergens() != null) {
			for (AllergenDTO allergenDTO : dto.getAllergens()) {
				// Obtén la entidad gestionada por ID
				Allergen allergen = allergenRepository.getReferenceById(allergenDTO.getId());
				ProductAllergen pa = new ProductAllergen();
				pa.setProduct(entity);
				pa.setAllergen(allergen);
				entity.getAllergens().add(pa);
			}
		}

		Product saved = productRepository.save(entity);
		return productMapper.toDTO(saved);
	}

	private void synchronizeImages(Product product, List<ProductImageDTO> imageDTOs) {
		// Mapear DTOs por ID
		Map<Long, ProductImageDTO> dtoMap = imageDTOs.stream().filter(dto -> dto.getId() != null)
				.collect(Collectors.toMap(ProductImageDTO::getId, dto -> dto));

		// Eliminar imágenes que ya no están
		List<ProductImage> toRemove = product.getImages().stream().filter(img -> !dtoMap.containsKey(img.getId()))
				.toList();

		product.getImages().removeAll(toRemove);

		// Actualizar las existentes
		for (ProductImage img : product.getImages()) {
			ProductImageDTO dto = dtoMap.get(img.getId());
			if (dto != null) {
				img.setImageUrl(dto.getImageUrl());
				img.setOrder(dto.getOrder());
			}
		}

		// Añadir las nuevas
		List<ProductImage> newImages = imageDTOs.stream().filter(dto -> dto.getId() == null).map(dto -> ProductImage
				.builder().imageUrl(dto.getImageUrl()).order(dto.getOrder()).product(product).build()).toList();

		product.getImages().addAll(newImages);
	}

	public ProductDTO updateProduct(Long id, ProductDTO dto) {
		Product existing = productRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));

		// Actualizar campos simples si no son null
		if (dto.getName() != null)
			existing.setName(dto.getName());

		if (dto.getDescription() != null)
			existing.setDescription(dto.getDescription());

		if (dto.getPrice() != null)
			existing.setPrice(dto.getPrice());

		if (dto.getStock() != null)
			existing.setStock(dto.getStock());

		// Flags booleanos (solo si no son null)
		if (dto.getAvailable() != null) {
			existing.setAvailable(dto.getAvailable());
		}

		if (dto.getPopular() != null) {
			existing.setPopular(dto.getPopular());
		}

		// Actualizar categoría si se proporciona
		if (dto.getCategoryId() != null) {
			ProductCategory category = new ProductCategory();
			category.setId(dto.getCategoryId());
			existing.setCategory(category);
		}

		// Sincronizar imágenes solo si se proporciona lista
		if (dto.getImages() != null && !dto.getImages().isEmpty()) {
			if (existing.getImages() == null) {
				existing.setImages(
						dto.getImages().stream()
								.map(imgDto -> ProductImage.builder().imageUrl(imgDto.getImageUrl())
										.order(imgDto.getOrder()).product(existing).build())
								.collect(Collectors.toList()));
			} else {
				synchronizeImages(existing, dto.getImages());
			}
		}

		Product updated = productRepository.save(existing);
		return productMapper.toDTO(updated);
	}

	public void deleteProduct(Long id) {
		if (!productRepository.existsById(id)) {
			throw new RuntimeException("Producto no encontrado con ID: " + id);
		}
		productRepository.deleteById(id);
	}
}
