package com.example.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.dto.ReviewDTO;
import com.example.entity.FoodOrder;
import com.example.entity.Review;
import com.example.entity.UserAccount;
import com.example.mapper.ReviewMapper;
import com.example.repository.FoodOrderRepository;
import com.example.repository.ReviewRepository;
import com.example.repository.UserAccountRepository;
import com.marketplace.exception.BusinessException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReviewService {

	private final ReviewRepository reviewRepository;
	private final ReviewMapper reviewMapper;
	private final UserAccountRepository userAccountRepository;
	private final FoodOrderRepository foodOrderRepository;

	public List<ReviewDTO> findAll() {
		return reviewRepository.findAll().stream().map(reviewMapper::toDTO).collect(Collectors.toList());
	}

	public List<ReviewDTO> getTopReviews() {
		return reviewRepository.findTopReviews().stream().map(reviewMapper::toDTO).toList();
	}

	public ReviewDTO create(ReviewDTO dto) {
		Review review = reviewMapper.toEntity(dto);

		// Buscar y asociar usuario
		UserAccount user = userAccountRepository.findById(dto.getUserId())
				.orElseThrow(() -> new BusinessException("Usuario no encontrado con ID: " + dto.getUserId()));

		// Buscar y asociar pedido
		FoodOrder order = foodOrderRepository.findById(dto.getOrderId())
				.orElseThrow(() -> new BusinessException("Pedido no encontrado con ID: " + dto.getOrderId()));

		review.setUser(user);
		review.setOrder(order);

		Review saved = reviewRepository.save(review);
		return reviewMapper.toDTO(saved);
	}

	public void delete(Long id) {
		if (!reviewRepository.existsById(id)) {
			throw new BusinessException("No existe reseña con ID: " + id);
		}
		reviewRepository.deleteById(id);
	}
}