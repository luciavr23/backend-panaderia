package com.example.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.dto.AdminStatsDTO;
import com.example.dto.PasswordUpdateDTO;
import com.example.dto.ProfileUpdateDTO;
import com.example.entity.FoodOrder;
import com.example.entity.UserAccount;
import com.example.enums.OrderStatusEnum;
import com.example.repository.FoodOrderRepository;
import com.example.repository.UserAccountRepository;

@Service
public class AdminService {

	@Autowired
	private FoodOrderRepository foodOrderRepository;

	@Autowired
	private UserAccountRepository userAccountRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	/* REVISAR EL CALCULO DE TIEMPO POR PEDIDO */
	public AdminStatsDTO getAdminStats() {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime firstDayOfMonth = now.with(TemporalAdjusters.firstDayOfMonth());
		LocalDateTime lastDayOfMonth = now.with(TemporalAdjusters.lastDayOfMonth());
		LocalDateTime firstDayOfLastMonth = firstDayOfMonth.minusMonths(1);
		LocalDateTime lastDayOfLastMonth = firstDayOfMonth.minusSeconds(1);

		// Pedidos del mes actual
		List<FoodOrder> currentMonthOrders = foodOrderRepository.findByCreatedAtBetween(firstDayOfMonth,
				lastDayOfMonth);
		// Pedidos del mes anterior
		List<FoodOrder> lastMonthOrders = foodOrderRepository.findByCreatedAtBetween(firstDayOfLastMonth,
				lastDayOfLastMonth);

		int totalOrders = currentMonthOrders.size();
		double totalRevenue = calculateTotalRevenue(currentMonthOrders);
		Map<String, Integer> ordersByStatus = calculateOrdersByStatus(currentMonthOrders);
		int avgPreparationTime = 15; // Simulado

		double growthOrders = calculateGrowth(totalOrders, lastMonthOrders.size());
		double growthRevenue = calculateGrowth(totalRevenue, calculateTotalRevenue(lastMonthOrders));
		AdminStatsDTO.GrowthDTO growth = AdminStatsDTO.GrowthDTO.builder().orders(growthOrders).revenue(growthRevenue)
				.build();

		return AdminStatsDTO.builder().totalOrders(totalOrders).totalRevenue(totalRevenue)
				.ordersByStatus(ordersByStatus).growth(growth).avgPreparationTime(avgPreparationTime).build();
	}

	public Map<String, Object> updateProfile(ProfileUpdateDTO profileUpdate) {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		UserAccount admin = userAccountRepository.findByEmail(username)
				.orElseThrow(() -> new RuntimeException("Admin no encontrado"));

		if (profileUpdate.getName() != null)
			admin.setName(profileUpdate.getName());
		if (profileUpdate.getEmail() != null)
			admin.setEmail(profileUpdate.getEmail());
		// No hay campo profileImage en UserAccount, puedes agregarlo si lo necesitas

		userAccountRepository.save(admin);

		Map<String, Object> response = new HashMap<>();
		response.put("message", "Perfil actualizado correctamente");
		response.put("admin", admin);
		return response;
	}

	public Map<String, String> changePassword(PasswordUpdateDTO passwordUpdate) {
		String username = SecurityContextHolder.getContext().getAuthentication().getName();
		UserAccount admin = userAccountRepository.findByEmail(username)
				.orElseThrow(() -> new RuntimeException("Admin no encontrado"));

		if (!passwordEncoder.matches(passwordUpdate.getCurrentPassword(), admin.getPassword())) {
			throw new RuntimeException("Contraseña actual incorrecta");
		}

		admin.setPassword(passwordEncoder.encode(passwordUpdate.getNewPassword()));
		userAccountRepository.save(admin);

		Map<String, String> response = new HashMap<>();
		response.put("message", "Contraseña actualizada correctamente");
		return response;
	}

	private double calculateTotalRevenue(List<FoodOrder> orders) {
		return orders.stream().map(FoodOrder::getTotalPrice).map(BigDecimal::doubleValue).reduce(0.0, Double::sum);
	}

	private Map<String, Integer> calculateOrdersByStatus(List<FoodOrder> orders) {
		Map<String, Integer> statusCount = new HashMap<>();
		for (OrderStatusEnum status : OrderStatusEnum.values()) {
			statusCount.put(status.name(), 0);
		}
		orders.forEach(order -> statusCount.merge(order.getStatus().name(), 1, Integer::sum));
		return statusCount;
	}

	private double calculateGrowth(double current, double previous) {
		if (previous == 0)
			return 100;
		return ((current - previous) / previous) * 100;
	}
}