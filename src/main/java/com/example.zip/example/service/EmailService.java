package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

	@Autowired
	private JavaMailSender mailSender;

	public void sendOrderEmail(String to, String subject, String htmlContent) throws MessagingException {
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
		helper.setTo(to);
		helper.setSubject(subject);
		helper.setText(htmlContent, true);

		mailSender.send(message);
	}

	public String buildOrderHtml(String cliente, String mensaje, String resumenPedido, String direccion,
			String telefono) {
		return """
				<html>
				  <body style='font-family: Arial, sans-serif;'>
				    <div style='text-align: center;'>
				      <img src='https://res.cloudinary.com/dzcym3dh4/image/upload/logoPanaderia' alt='Panadería Ana' style='width: 120px; margin-bottom: 20px;' />
				      <h2>¡Hola, %s!</h2>
				      <p>%s</p>
				      <p>%s</p>
				      %s
				      <hr/>
				      <small>Este es un mensaje automático, no respondas a este correo.</small>
				    </div>
				  </body>
				</html>
				"""
				.formatted(cliente, mensaje, resumenPedido,
						(direccion != null && telefono != null)
								? "<p><b>Dirección:</b> " + direccion + "<br/><b>Teléfono:</b> " + telefono + "</p>"
								: "");
	}

	public String buildResumenPedidoHtml(String numeroPedido, java.util.List<String> productos, double total,
			String fechaRecogida) {
		StringBuilder sb = new StringBuilder();
		sb.append("<b>Pedido #").append(numeroPedido).append("</b><br/>");
		sb.append("<ul style='text-align:left; display:inline-block;'>");
		for (String prod : productos) {
			sb.append("<li>").append(prod).append("</li>");
		}
		sb.append("</ul>");
		sb.append("<b>Total:</b> ").append(String.format("%.2f", total)).append(" €<br/>");
		if (fechaRecogida != null) {
			sb.append("<b>Recogida estimada:</b> ").append(fechaRecogida).append("<br/>");
		}
		return sb.toString();
	}
}