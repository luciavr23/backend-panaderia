package com.example.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.dto.UserAccountDTO;
import com.example.entity.UserAccount;
import com.example.enums.UserRole;
import com.example.mapper.UserAccountMapper;
import com.example.repository.UserAccountRepository;
import com.example.security.JwtTokenProvider;
import com.example.util.ValidationUtil;
import com.marketplace.exception.BusinessException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserAccountService {

	private final UserAccountRepository userAccountRepository;
	private final UserAccountMapper userMapper;
	private final ValidationUtil validationUtil;
	private final PasswordEncoder passwordEncoder;
	private final JwtTokenProvider jwtTokenProvider;
	private final EmailService emailService;

	public UserAccountDTO getUserProfile(String email) {
		return userAccountRepository.findByEmail(email).map(userMapper::toDTO)
				.orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
	}

	// Registro
	public Map<String, Object> registerUser(UserAccountDTO userDTO) {
		List<String> errors = new ArrayList<>();
		UserRole roleEnum;
		try {
			roleEnum = userDTO.getRole() == null ? UserRole.CLIENT : UserRole.valueOf(userDTO.getRole().toUpperCase());
		} catch (IllegalArgumentException e) {
			throw new BusinessException(List.of("Rol inválido: debe ser CLIENT o ADMIN"));
		}

		// ───── Validación: Email único por rol ─────
		if (userAccountRepository.existsByEmail(userDTO.getEmail())) {
			errors.add("El email ya está registrado.");
		}

		if (!validationUtil.isValidEmail(userDTO.getEmail())) {
			errors.add("El email no tiene un formato válido.");
		}

		// ───── Validación: Teléfono (si se proporciona) ─────
		if (userDTO.getPhoneNumber() != null && !userDTO.getPhoneNumber().trim().isBlank()
				&& !validationUtil.isValidPhone(userDTO.getPhoneNumber())) {
			errors.add("El teléfono debe tener 9 dígitos.");
		}

		// ───── Validación: Contraseña ─────
		if (!validationUtil.isValidPassword(userDTO.getPassword())) {
			errors.add(
					"La contraseña debe tener al menos 8 caracteres, incluir mayúsculas, minúsculas, números y un carácter especial.");
		}

		// ───── Si hay errores, lanzar excepción ─────
		if (!errors.isEmpty()) {
			throw new BusinessException(errors);
		}

		// ───── Guardar usuario ─────
		UserAccount user = userMapper.toEntity(userDTO);
		user.setPassword(passwordEncoder.encode(userDTO.getPassword())); // Encripta la contraseña
		user.setRole(roleEnum);
		UserAccount savedUser = userAccountRepository.save(user);

		// ───── Generar token JWT ─────
		String token = jwtTokenProvider.generateToken(savedUser);

		// ───── Preparar respuesta ─────
		Map<String, Object> response = new HashMap<>();
		response.put("user", userMapper.toDTO(savedUser));
		response.put("token", token);
		return response;
	}

	public void generateResetTokenAndSendEmail(String email) {
		UserAccount user = userAccountRepository.findByEmail(email)
				.orElseThrow(() -> new BusinessException("No existe usuario con ese email"));
		String token = UUID.randomUUID().toString();
		user.setResetToken(token);
		user.setResetTokenExpiry(LocalDateTime.now().plusHours(1));
		userAccountRepository.save(user);
		// Enviar email
		String resetLink = "http://localhost:3000/reset-password?token=" + token;
		String html = "<p>Hola, " + user.getName()
				+ ".<br>Has solicitado restablecer tu contraseña. Haz clic en el siguiente enlace para continuar:</p>"
				+ "<a href='" + resetLink + "'>Restablecer contraseña</a>"
				+ "<p>Si no solicitaste este cambio, ignora este correo.</p>";
		try {
			emailService.sendOrderEmail(user.getEmail(), "Recuperación de contraseña - Panadería Ana", html);
		} catch (Exception e) {
			e.printStackTrace();
			throw new BusinessException("No se pudo enviar el email de recuperación");
		}
	}

	public void resetPassword(String token, String newPassword) {
		UserAccount user = userAccountRepository.findByResetToken(token)
				.orElseThrow(() -> new BusinessException("Token inválido"));
		if (user.getResetTokenExpiry() == null || user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
			throw new BusinessException("El token ha expirado");
		}
		user.setPassword(passwordEncoder.encode(newPassword));
		user.setResetToken(null);
		user.setResetTokenExpiry(null);
		userAccountRepository.save(user);
	}

}