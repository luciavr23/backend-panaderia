package com.example.enums;

public enum WeekdayEnum {
	LUNES, MARTES, MIÉRCOLES, JUEVES, VIERNES, SÁBADO, DOMINGO
}