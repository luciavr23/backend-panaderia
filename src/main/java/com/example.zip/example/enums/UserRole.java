package com.example.enums;

public enum UserRole {
	CLIENT, ADMIN
}