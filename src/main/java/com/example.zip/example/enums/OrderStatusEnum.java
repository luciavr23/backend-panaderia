package com.example.enums;

public enum OrderStatusEnum {
	PENDIENTE, EN_PREPARACIÓN, LISTO, CANCELADO
}
