package com.example.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.FoodOrderDTO;
import com.example.entity.FoodOrder;
import com.example.enums.OrderStatusEnum;
import com.example.repository.FoodOrderRepository;
import com.example.service.FoodOrderService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
public class FoodOrderController {
	private final FoodOrderService foodOrderService;
	private final FoodOrderRepository foodOrderRepository;

	// Endpoint para obtener los pedidos del usuario autenticado
	@GetMapping("/my")
	public ResponseEntity<List<FoodOrderDTO>> getMyOrders(Authentication authentication) {
		String username = authentication.getName();
		List<FoodOrderDTO> orders = foodOrderService.getOrdersByUsername(username);
		return ResponseEntity.ok(orders);
	}

	@GetMapping("/user/{userId}")
	public ResponseEntity<List<FoodOrderDTO>> getOrdersByUserId(@PathVariable Long userId) {
		List<FoodOrderDTO> orders = foodOrderService.getOrdersByUserId(userId);
		return ResponseEntity.ok(orders);
	}

	@PostMapping
	public ResponseEntity<FoodOrderDTO> createOrder(@RequestBody FoodOrder order, Authentication authentication) {
		String email = authentication.getName();

		// Delegate order creation to the service
		FoodOrderDTO dto = foodOrderService.createOrderWithUser(order, email);

		return ResponseEntity.ok(dto);
	}

	// Endpoint para cambiar el estado del pedido
	@PutMapping("/{orderId}/status")
	public ResponseEntity<?> updateOrderStatus(@PathVariable Long orderId, @RequestParam String status,
			@RequestParam(required = false) String fechaRecogida) {
		FoodOrder pedido = foodOrderRepository.findById(orderId)
				.orElseThrow(() -> new RuntimeException("Pedido no encontrado"));
		pedido.setStatus(OrderStatusEnum.valueOf(status));
		foodOrderRepository.save(pedido);

		// Notificaciones automáticas
		switch (pedido.getStatus()) {
		case PENDIENTE -> foodOrderService.notificarPedidoRegistrado(pedido);
		case LISTO -> foodOrderService.notificarPedidoCompletado(pedido, fechaRecogida);
		case CANCELADO -> foodOrderService.notificarPedidoCancelado(pedido);
		default -> {
		}
		}
		return ResponseEntity.ok().build();
	}
}