package com.example.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReviewDTO {
	private Long id;
	private Long userId;
	private String userName; // nombre del usuario (ej: "Emma")
	private Double stars; // estrellas
	private String comment; // comentario
	private LocalDateTime createdAt; // fecha de creación
	private Long orderId; // número de pedido
}
