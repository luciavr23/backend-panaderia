/*
 * package com.example.config;
 * 
 * 
 * @Configuration
 * 
 * @ConfigurationProperties(prefix = "oauth2.client")
 * 
 * @Data public class OAuth2Properties { private final Provider provider = new
 * Provider(); private final Registration registration = new Registration();
 * 
 * @Data public static class Provider { private String authorizationUri; private
 * String tokenUri; private String userInfoUri; private String jwkSetUri; }
 * 
 * @Data public static class Registration { private String clientId; private
 * String clientSecret; private String redirectUri; } }
 */
