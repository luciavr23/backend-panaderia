/*
 * package com.example.config;
 * 
 * import org.springframework.beans.factory.annotation.Value; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.security.oauth2.client.registration.ClientRegistration;
 * import org.springframework.security.oauth2.client.registration.
 * ClientRegistrationRepository; import
 * org.springframework.security.oauth2.client.registration.
 * InMemoryClientRegistrationRepository; import
 * org.springframework.security.oauth2.core.AuthorizationGrantType; import
 * org.springframework.security.oauth2.core.ClientAuthenticationMethod; import
 * org.springframework.security.oauth2.core.oidc.IdTokenClaimNames;
 * 
 * 
 * @Configuration public class OAuth2ClientConfig {
 * 
 * @Value("${oauth2.client.provider.authorization-uri}") private String
 * authorizationUri;
 * 
 * @Value("${oauth2.client.provider.token-uri}") private String tokenUri;
 * 
 * @Value("${oauth2.client.registration.client-id}") private String clientId;
 * 
 * @Value("${oauth2.client.registration.client-secret}") private String
 * clientSecret;
 * 
 * @Value("${oauth2.client.registration.redirect-uri}") private String
 * redirectUri;
 * 
 * @Value("${oauth2.client.provider.jwk-set-uri}") private String jwkSetUri;
 * 
 * @Value("${oauth2.client.provider.user-info-uri}") private String userInfoUri;
 * 
 * @Bean public ClientRegistration clientRegistration() { return
 * ClientRegistration.withRegistrationId("marketplace").clientId(clientId).
 * clientSecret(clientSecret)
 * .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
 * .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE).
 * redirectUri(redirectUri) .scope("openid", "profile",
 * "email").authorizationUri(authorizationUri).tokenUri(tokenUri)
 * .userInfoUri(userInfoUri).jwkSetUri(jwkSetUri).userNameAttributeName(
 * IdTokenClaimNames.SUB) .clientName("Marketplace").build(); }
 * 
 * 
 * @Bean public ClientRegistrationRepository
 * clientRegistrationRepository(ClientRegistration clientRegistration) { return
 * new InMemoryClientRegistrationRepository(clientRegistration); } }
 */