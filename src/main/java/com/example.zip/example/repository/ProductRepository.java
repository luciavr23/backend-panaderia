package com.example.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
	List<Product> findByAvailableTrue();

	List<Product> findByPopularTrue();

	Page<Product> findByCategoryId(Long categoryId, Pageable pageable);

	Page<Product> findByCategoryIdAndNameContainingIgnoreCase(Long categoryId, String name, Pageable pageable);

	Page<Product> findByNameContainingIgnoreCase(String name, Pageable pageable);

	Page<Product> findByAvailableTrue(Pageable pageable);

	Page<Product> findByAvailableTrueAndCategoryId(Long categoryId, Pageable pageable);

	Page<Product> findByAvailableTrueAndCategoryIdAndNameContainingIgnoreCase(Long categoryId, String name,
			Pageable pageable);

	Page<Product> findByAvailableTrueAndNameContainingIgnoreCase(String name, Pageable pageable);

}
