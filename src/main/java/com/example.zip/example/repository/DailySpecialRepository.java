package com.example.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entity.DailySpecial;
import com.example.enums.WeekdayEnum;

@Repository
public interface DailySpecialRepository extends JpaRepository<DailySpecial, Long> {
	Optional<DailySpecial> findByWeekday(WeekdayEnum weekday);

}
